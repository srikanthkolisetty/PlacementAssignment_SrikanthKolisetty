package com.base;

public class MainProg {
	
	public static void main(String[] args) {
		
		One o = new One();
		o.setId(1);
		o.setAge("23");
		o.setCourse("english");
		o.setName("nitin");
		Connect c= new Connect();
		System.out.println("Before");
		c.display(1);
		c.update(o);
		System.out.println("after");
		c.display(1);
	}
}
