import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.swing.GroupLayout.Group;

class Student {
	public Student(String name, String address, String medium, int age) {
		this.name = name;
		this.address = address;
		this.medium = medium;
		this.age = age;
	}

	public String name;
	public String address;
	public String medium;
	@Override
	public String toString() {
		return "Student [name=" + name + ", address=" + address + ", medium=" + medium + ", age=" + age + "]";
	}

	public int age;

}

public class StreamExample {
	public static void main(String[] args) {

		List<Student> stu = new ArrayList<>();
		
		stu.add(new Student("srikanth","bmps","eng",23));
		stu.add(new Student("sri","b","eng",21));
		stu.add(new Student("kanth","mps","tel",33));
		stu.add(new Student("siri","bmps","tamil",13));
		stu.add(new Student("shiva","bps","urdu",34));
		stu.add(new Student("delp","nrt","eng",23));
		stu.add(new Student("dinesh","gnt","eng",23));
		stu.add(new Student("yada","gnt","hindi",23));
		stu.add(new Student("nidi","nrt","chinese",23));
		stu.add(new Student("sourav","gnt","hindi",23));
		stu.add(new Student("sanjay","vnk","eng",23));
		stu.add(new Student("suresh","vnk","tel",23));
		stu.add(new Student("suraj","sap","tel",23));
		stu.add(new Student("subhajit","sap","eng",23));
		stu.add(new Student("senior","pdg","eng",23));
		stu.add(new Student("sewag","pdg","eng",23));
		stu.add(new Student("sachin","hyd","eng",23));
		stu.add(new Student("sampath","hyd","eng",23));
		stu.add(new Student("shamboo","bang","eng",23));
		stu.add(new Student("sarayu","bang","eng",23));

		//sorting based on age
		stu.stream().sorted((stu1,stu2)->Integer.compare(stu1.age, stu2.age)).forEach(System.out::println);
	
		//filtering and then grouping
		
		Map<Integer, List<Student>> map = stu.stream().filter(stud-> stud.medium.equals("eng")).collect(Collectors.groupingBy(stud->stud.age));
		
		//limit 
		System.out.println("limit");
		stu.stream().limit(6).forEach(System.out::println);
		//finding out whether all students age is 23 or not 
		System.out.println(stu.stream().allMatch(stud->stud.age==23));
	}

}
