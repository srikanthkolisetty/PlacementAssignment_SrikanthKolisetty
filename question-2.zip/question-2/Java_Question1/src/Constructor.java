
class Parent
{
	public Parent()
	{
		System.out.println("inside the parent class constructor");
	}
	
	public Parent(int a)
	{
		System.out.println("parameterized constructor");
	}
}


public class Constructor extends Parent{

	public Constructor()
	{
		super();
		System.out.println("kk");
	}
	
	public Constructor(int a )
	{
		super(a);
	}
	public static void main(String[] args) {
		
		new Constructor();
		new Constructor(10);
	}
//	Constructor is special type  of method which will be invoked at the time of
//	object creation
//	it will be called once per object
//	it can be overloaded
//	it should not have any return type
//	To invoke parent class constructor we should use super() and the
//	call for parent class constructor will be the first statement in
//	the constructor i.e super() should be the first statement.
//	constructor can be overloaded even
// generally if we not include super() in child class constructor also parent class zero arg constructor will be invoked
// if parent class has parameterized constructor and not having zero param constructor then we should explicitly call parameterized constructor. 
}
