package com.example.service;

import java.util.List;

import com.example.dto.Product;

public interface IService {

	public String insert(Product u);
	
	public List<Product> readAll();
	
	public Product read(Integer id) throws Exception;
	
	public String  put(Integer id) throws Exception;
	
	public String partial(Integer id) throws Exception;
	
	public String delete(Integer id) throws Exception;
	
	
}
