package com.example.repo;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.example.dto.Product;

public interface Sort extends PagingAndSortingRepository<Product, Integer> {

	
	
}
