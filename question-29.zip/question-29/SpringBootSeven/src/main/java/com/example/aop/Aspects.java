package com.example.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class Aspects {

	
	@Pointcut("execution(* com.example.service.IServiceImpl.*(..))")
	public void pointOne()
	{
		
	}
	
	@Pointcut("execution(* com.example..*.delete(..))")
	public void pointTwo()
	{
		
	}
	
	// for delete method present in service package
	// integrating two pointcuts
	@Before("pointOne() && pointTwo()")
	public void adviceOne(JoinPoint p)
	{
		System.out.println("method name is"+p.getSignature().getName());
		Object[] args = p.getArgs();
		System.out.println("parameters for the method are");
		for(Object obj:args)
		{
			System.out.println(obj);
		}
	
	}
	
	@After("pointOne()")
	public void adviceThree(JoinPoint p)
	{
		System.out.println("method name is"+p.getSignature().getName());
		Object[] args = p.getArgs();
		System.out.println("parameters for the method are "+ (args.length==0? "empty":" "));
		for(Object obj:args)
		{
			System.out.println(obj);
		}
	
	}
	
	
	@AfterReturning(pointcut="pointOne() && pointTwo()",returning = "value")
	public void adviceTwo(JoinPoint p, Object value)
	{
		System.out.println("in aop advice");
		System.out.println(value.toString());
		System.out.println(p.getSignature().getName());
	}
	// similarly we can also use pointcuts for other methods 
}
