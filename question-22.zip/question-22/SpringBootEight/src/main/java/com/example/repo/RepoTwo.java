package com.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.dto.Order;

public interface RepoTwo extends JpaRepository<Order, Integer> {
	
	@Query("From Order where ud.id=:uid")
	public List<Order> findOrdersByUid(@Param("uid") Integer uid);

	@Query("From Order where ud.id=:uid and  ord_price=:pri")
	public List<Order> findOrdersByUid(@Param("uid") Integer uid,@Param("pri")Integer pri);
}
