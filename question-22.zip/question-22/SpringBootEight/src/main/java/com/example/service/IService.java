package com.example.service;

import java.util.List;

import com.example.dto.Order;
import com.example.dto.User;

public interface IService {
	
	public List<Order> getOrdersBasedUid(Integer id);

	public String insertUser(User r);
	public String insertOrder(Order r);
	
	public List<Order> getOrdersByPrice(Integer id,Integer price);
	
}
