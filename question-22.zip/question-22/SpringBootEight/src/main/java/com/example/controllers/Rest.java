package com.example.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.Order;
import com.example.dto.User;
import com.example.repo.RepoOne;
import com.example.repo.RepoTwo;
import com.example.service.IService;

@RestController
public class Rest {

	/*
	 * user can hit different endpoints and get their associated orders(querying their orders based id and price etc..)
	 */
	
	@Autowired
	private IService IServiceImpl;
	
	@GetMapping("/getOrders/{userid}")
	public <T extends Object>ResponseEntity<T> getOrders(@PathVariable Integer userid)
	{
		ArrayList<Order> uid = (ArrayList)IServiceImpl.getOrdersBasedUid(userid);
		if(uid.size()==0)
			return (ResponseEntity<T>) new ResponseEntity<String>("no orders for your user",HttpStatus.OK);
		else
			return (ResponseEntity<T>) new ResponseEntity<ArrayList>(uid,HttpStatus.OK);
	}
	
	@GetMapping("/getOrdersByPrice/{userid}")
	public <T extends Object>ResponseEntity<T> getOrders(@RequestParam String price,@PathVariable Integer userid)
	{
		ArrayList<Order> uid = (ArrayList)IServiceImpl.getOrdersByPrice(userid,Integer.parseInt(price));
		if(uid.size()==0)
			return (ResponseEntity<T>) new ResponseEntity<String>("no orders for your user",HttpStatus.OK);
		else
			return (ResponseEntity<T>) new ResponseEntity<ArrayList>(uid,HttpStatus.OK);
	}
	
	@PostMapping("/insertUser")
	public ResponseEntity<String> insertUser(@RequestBody User u)
	{
		IServiceImpl.insertUser(u);
		return new ResponseEntity<String>("inserted",HttpStatus.OK);
	}
	

	@PostMapping("/insertOrder")
	public ResponseEntity<String> insertOrder(@RequestBody Order u)
	{
		IServiceImpl.insertOrder(u);
		return new ResponseEntity<String>("inserted",HttpStatus.OK);
	}
	
	

	
	
	
}
