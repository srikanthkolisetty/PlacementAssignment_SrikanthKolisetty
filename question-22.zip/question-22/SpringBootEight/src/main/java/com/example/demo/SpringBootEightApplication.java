package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.example.dto.Order;
import com.example.dto.User;
import com.example.repo.RepoOne;
import com.example.repo.RepoTwo;

@SpringBootApplication(scanBasePackages = "com.example")
@EntityScan(basePackages = "com.example.dto")
@EnableJpaRepositories(basePackages = "com.example.repo")
public class SpringBootEightApplication {

	@Autowired
	private RepoOne rep;
	
	@Autowired
	private RepoTwo rep2;
	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(SpringBootEightApplication.class, args);
				
		run.getBean(SpringBootEightApplication.class).ine(); // just made for some data to be inserted
		
	}
	public void ine()
	{
		User u= new User();
		u.setAge(23);
		u.setGender("mae");
		
		u.setName("sri");
		
		Order o = new Order();
		o.setOrd_price(283);
		o.setUd(u);
		u.setOrd(List.of(o));
		Order o1 = new Order();
		o1.setOrd_price(282);
		o1.setUd(u);
		u.setOrd(List.of(o,o1));
		rep.save(u);
		
	}
}
