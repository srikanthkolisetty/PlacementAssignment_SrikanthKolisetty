package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.Order;
import com.example.dto.User;
import com.example.repo.RepoOne;
import com.example.repo.RepoTwo;

@Service
public class IServiceImpl implements IService{

	@Autowired
	private RepoOne rep;
	@Autowired
	private RepoTwo rep2;
	@Override
	public List<Order> getOrdersBasedUid(Integer id) {
		// TODO Auto-generated method stub
		
		List<Order> ordersByUid = rep2.findOrdersByUid(id);
		return ordersByUid;
		
	}
	
	
	public List<Order> getOrdersByPrice(Integer id,Integer price) {
		// TODO Auto-generated method stub
		
		List<Order> ordersByUid = rep2.findOrdersByUid(id, price);
		return ordersByUid;
		
	}
	@Override
	public String insertUser(User r) {
		// TODO Auto-generated method stub
		User save = rep.save(r);
		if(save!=null)
			return "inserted";
		return "notinserted";
	}
	@Override
	public String insertOrder(Order r) {
	
		Order save2 = rep2.save(r);
		if(save2!=null)
			return "inserted";
		return "notinserted";
		// TODO Auto-generated method stub
	}
}
