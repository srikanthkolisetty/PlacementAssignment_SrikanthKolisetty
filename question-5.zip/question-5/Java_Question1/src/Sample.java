interface One
{
	void one();
	void two();
	static final int b=200;
}

abstract class Two implements One
{
	public Two()
	{
		System.out.println("inside the abstract class constructor ");
	}
	public void one()
	{
		System.out.println("in the abstract class");
	}
	
	public void three()
	{
		System.out.println("extra method");
	}
	
	public abstract void four();
}
public class Sample extends Two{

	@Override
	public void two() {
		// TODO Auto-generated method stub
		System.out.println("two method");
	}
	
	public void four()
	{
		System.out.println("abstract methods implementation");
	}
	// interface is pure abstraction
	//abstract class is not pure abstraction
	//abstract class can have abstract methods as well as concrete methods
	// class can be abstract even if it is not having any abstract methods
	// abstract is the keyword which is used to declare abstract methods
	// The above approach is called as adapter design where abstract class implements
	// interface and provide implementation for few methods, remaining mehods will act
	// as abstract methods.
	//abstract class should be extended and interface should be implemented
	// A class if extends abstract class then it should provide implementation to abstract methods
	//No object creation for interface and abstract class
}
