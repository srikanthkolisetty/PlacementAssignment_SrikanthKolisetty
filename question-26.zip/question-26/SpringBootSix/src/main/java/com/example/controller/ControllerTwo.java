package com.example.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ControllerTwo {

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> excep(Exception e)
	{
		e.printStackTrace();
		return new ResponseEntity<>("exception occured", HttpStatus.BAD_GATEWAY);
	}
}
