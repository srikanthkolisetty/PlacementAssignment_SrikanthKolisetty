package com.example.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.Product;
import com.example.service.IService;

@RestController
public class Controller {

	@Autowired
	private IService ser;
	
	@PostMapping("/insertProduct")
	public ResponseEntity<String> insert(@RequestBody Product u, Map<String,String> m)
	{
		if(ser.insert(u).equalsIgnoreCase("record not inserted"))
		return new ResponseEntity<String>("record not inserted", HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<String>("record inserted", HttpStatus.OK);
			
	}
	
	@GetMapping("/getProducts")
	public ResponseEntity<List<Product>> readAllProducts( Map<String,String> m)
	{
		List<Product> readAll = ser.readAll();
		return new ResponseEntity<List<Product>>(readAll, HttpStatus.OK);
	}
	
	@GetMapping("/getProduct/{id}")
	public ResponseEntity<Product> read(@PathVariable Integer id, Map<String,String> m) throws Exception
	{
		
		return new ResponseEntity<Product>(ser.read(id), HttpStatus.OK);
	}
	
	@PutMapping("/updateProduct/{id}")
	public ResponseEntity<String> put(@PathVariable Integer id, Map<String,String> m) throws Exception
	{	
		Product p= ser.read(id);
		p.setName("mobile");
		p.setPrice(2343);
		p.setType("electronics");
		
		return new ResponseEntity<String>(ser.insert(p).replace("inserted","updated"), HttpStatus.OK);
	}
	
	@PatchMapping("/partialUpdation/{id}")
	public ResponseEntity<String> partial(@PathVariable Integer id, Map<String,String> m) throws Exception
	{
		Product p= ser.read(id);
		p.setName("mobile");
	
		return new ResponseEntity<String>(ser.insert(p).replace("inserted","updated"), HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> delete(@PathVariable Integer id, Map<String,String> m) throws Exception
	{
		return new ResponseEntity<String>(ser.delete(id), HttpStatus.OK);
	}
	
}
