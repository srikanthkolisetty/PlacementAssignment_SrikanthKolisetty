package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.Product;
import com.example.repo.Repo;

@Service
public class IServiceImpl implements IService {

	@Autowired
	private Repo repo;

	@Override
	public String insert(Product u) {
		// TODO Auto-generated method stub
		Product save = repo.save(u);
		return  save!=null? "product inserted":"product not inserted";
	}

	@Override
	public List<Product> readAll() {
		// TODO Auto-generated method stub
		List<Product> findAll = repo.findAll();
		return findAll;
	}

	@Override
	public Product read(Integer id) throws Exception {
		// TODO Auto-generated method stub
	return  repo.findById(id).orElseThrow(()-> new Exception());
		
	}


	@Override
	public String delete(Integer id) throws Exception {
		// TODO Auto-generated method stub
		Product product = repo.findById(id).orElseThrow(()-> new Exception());
		
		repo.delete(product);
		return "product deleted";
	}

	@Override
	public String put(Integer id) throws Exception {
		// TODO Auto-generated method stub
		Product p= repo.findById(id).orElseThrow(()-> new Exception());
		p.setName("mobile");
		p.setPrice(2343);
		p.setType("electronics");
		Product save = repo.save(p);
		return  save!=null? "product updated":"product not updated";

	}

	@Override
	public String partial(Integer id) throws Exception {
		// TODO Auto-generated method stub
		Product p= repo.findById(id).orElseThrow(()-> new Exception());
		p.setName("mobile");
		Product save = repo.save(p);
		return  save!=null? "product updated":"product not updated";
		
	}
	

}
