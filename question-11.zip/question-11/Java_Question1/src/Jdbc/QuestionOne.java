package Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QuestionOne {

	static Connection con;
	static {
		try {
			con = DriverManager.getConnection("jdbc:mysql:///ineuron", "root", "admin");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		try {
			System.out.println("in");
			PreparedStatement st = con.prepareStatement("select * from course");
			if (st != null) {
				ResultSet resultSet = st.executeQuery();
				if (resultSet!=null) {
					while (resultSet.next()) {
						System.out.print(resultSet.getInt(1) + " " + resultSet.getString("name"));
						System.out.println();
					}
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
		}

	}
}
