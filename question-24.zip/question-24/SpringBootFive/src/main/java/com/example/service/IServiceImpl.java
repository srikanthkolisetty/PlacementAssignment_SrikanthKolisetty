package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.User;
import com.example.repo.Repo;

@Service
public class IServiceImpl implements IService {

	@Autowired
	private Repo repo;
	@Override
	public String insert(User u) {
		
		User save = repo.save(u);
		if(save !=null)
			return "welcome";
		return "error";
	}

}
