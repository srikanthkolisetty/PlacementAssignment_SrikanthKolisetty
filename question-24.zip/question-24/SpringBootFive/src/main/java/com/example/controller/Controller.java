package com.example.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.User;
import com.example.service.IService;

@RestController
public class Controller {

	@Autowired
	private IService ser;
	
	@PostMapping("/insert")
	public ResponseEntity<String> register(@RequestBody User u, Map<String,String> m)
	{
		System.out.println("reg");
		String s= ser.insert(u);
		
		return new ResponseEntity<String>("record inserted", HttpStatus.OK);
	}
	
}
