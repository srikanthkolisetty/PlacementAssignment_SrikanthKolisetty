
public class Triangle implements Shape {

	@Override
	public int area(int a, int b) {
		// TODO Auto-generated method stub
		return a*b;
	}

	@Override
	public int perimeter(int a, int b) {
		// TODO Auto-generated method stub
		// formula is taken  for sample
		return 2*(a+b);
	}

}
