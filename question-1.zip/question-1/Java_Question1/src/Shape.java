
public interface Shape {

	int area(int a,int b);
	int perimeter(int a,int b);
}
