package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.dto.Blog;

public class jdbc {

	static Connection con;
		
	public String insert(String title, String desc, String content) throws SQLException {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		con = DriverManager.getConnection("jdbc:mysql:///ineuron", "root", "admin");

		PreparedStatement st1 = con.prepareStatement("insert into blog values(?,?,?)");
		st1.setString(1, title);
		st1.setString(2, desc);
		st1.setString(3, content);
		int i = st1.executeUpdate();
		return i > 0 ? "record inserted" : "record not inserted";

	}

	public List<Blog> select() {

		
		ArrayList<Blog> a = new ArrayList();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql:///ineuron", "root", "admin");

			PreparedStatement st = con.prepareStatement("select * from blog");
			if (st != null) {
				ResultSet resultSet = st.executeQuery();
				if (resultSet != null) {
					while (resultSet.next()) {
						a.add(new Blog(resultSet.getString(1), resultSet.getString(2),resultSet.getString(3)));
					}
				}

			}
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;

	}
}
