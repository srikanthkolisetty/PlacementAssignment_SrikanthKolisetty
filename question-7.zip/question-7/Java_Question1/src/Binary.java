import java.util.Scanner;

public class Binary {
	
	public static void main(String[] args) {
		
		int a[]= {1,2,3,4,5,6,7,10,21};
		
		int beg=0;
		int end=a.length-1;
		System.out.println("enter the number you want to search");
		int target=new Scanner(System.in).nextInt();
		boolean found=false;
		while(beg<=end)
		{
			int mid=(beg+end)/2;
			if(a[mid]==target)
			{
				System.out.println("found at position"+mid);
				found=true;
				break;
			}
			else if(a[mid]>target)
				end=mid-1;
			else if(a[mid]<target)
				beg=mid+1;
		}
		if(!found)
			System.out.println("entered number is not found");
	}
}
