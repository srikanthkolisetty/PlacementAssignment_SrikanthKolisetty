package com.example.service;

import com.example.dto.User;

public interface IService {

	public String insert(User u);
	
	public String find(String mail,String password);
}
