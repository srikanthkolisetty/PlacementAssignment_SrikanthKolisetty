package com.example.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.dto.User;

public interface Repo extends JpaRepository<User, Integer> {
	
	
	public User findByMailAndPass(String mail,String pass);
}
