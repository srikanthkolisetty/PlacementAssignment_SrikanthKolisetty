package com.example.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.dto.User;
import com.example.service.IService;

@org.springframework.stereotype.Controller
@RequestMapping("/controller")
public class Controller {
	
	@Autowired
	private IService ser;

	
	@RequestMapping("/register")
	public String register(User u, Map<String,String> m)
	{
		System.out.println("reg");
		String s= ser.insert(u);
		m.put("name",u.getName());
		return s;
	}
	@RequestMapping("/registerPage")
	public String page1()
	{
		return "register";
	}
	
	@RequestMapping("/loginPage")
	public String page2()
	{
		return "login";
	}

	@RequestMapping("/login")
	public String login(@RequestParam String mail,@RequestParam String pass, Map<String,String> m)
	{
		
		String s= ser.find(mail,pass);
		String a[]=s.split(" ");
		m.put("name",a[1]);
		return a[0];
	}

}
