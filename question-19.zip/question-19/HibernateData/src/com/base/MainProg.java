package com.base;

public class MainProg {
	
	public static void main(String[] args) {
		
		One o = new One();
		o.setAge("23");
		o.setCourse("java");
		o.setName("nitin");
		Connect c= new Connect();
		c.display(1);
	}
}
