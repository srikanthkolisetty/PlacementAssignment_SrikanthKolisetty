package com.base;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Connect {
	
		
		public void display(Integer id)
		{
			Session session;
			Configuration c = new Configuration();
			c.configure();
			SessionFactory factory = c.buildSessionFactory();
			session = factory.openSession();
			try {
				One o = session.get(One.class,id);			
				System.out.println(o);
			}
			catch(HibernateException e)
			{
				e.printStackTrace();
			}
		
		}
	
}
