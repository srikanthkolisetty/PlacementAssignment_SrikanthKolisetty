package com.main;

public class Course {

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer id;
	public String name;
	public Course(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	
}
