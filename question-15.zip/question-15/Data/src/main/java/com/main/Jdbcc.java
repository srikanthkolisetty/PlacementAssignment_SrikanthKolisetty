package com.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Jdbcc {

	static Connection con;
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql:///ineuron", "root", "admin");
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<Course> getData()
	{
		ArrayList<Course> a= new ArrayList();
		try {
			PreparedStatement st = con.prepareStatement("select * from course");
			if (st != null) {
				ResultSet resultSet = st.executeQuery();
				if (resultSet!=null) {
					while (resultSet.next()) {
						a.add(new Course(resultSet.getInt(1),resultSet.getString("name")));
						System.out.println(a);
					}
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
		return a;
	}
}
