package com.base;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Connect {
	
	public Integer insert(One obj)
	{
		Session session;
		Configuration c = new Configuration();
		c.configure();
		SessionFactory factory = c.buildSessionFactory();
		session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			Serializable save = session.save(obj);			
			transaction.commit();			
			return (Integer)save;
		}
		catch(HibernateException e)
		{
			transaction.rollback();
		}
		return null;
	}
		
		public void display(Integer id)
		{
			Session session;
			Configuration c = new Configuration();
			c.configure();
			SessionFactory factory = c.buildSessionFactory();
			session = factory.openSession();
			try {
				One o = session.get(One.class,id);			
				System.out.println(o);
			}
			catch(HibernateException e)
			{
				e.printStackTrace();
			}
		
		}
	
}
