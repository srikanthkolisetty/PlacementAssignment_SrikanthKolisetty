import java.util.ArrayList;
import java.util.Scanner;

public class Listt {
	public static void main(String[] args) {
		
		System.out.println("enter how many numbers you want");
		int n=new Scanner(System.in).nextInt();
	
		ArrayList<Integer> a= new ArrayList();
		for(int i=0;i<n;i++)
		{
			System.out.println("enter number");
			a.add(new Scanner(System.in).nextInt());
		}
		a.sort((Integer i1,Integer i2)->Integer.compare(i1, i2));
		System.out.println("largest element is "+a.get(a.size()-1));
		System.out.println("Smallest element is"+a.get(0));
		
	}
}
