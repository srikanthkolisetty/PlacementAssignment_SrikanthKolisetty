package Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Crud {

	static Connection con;
	static {
		try {
			con = DriverManager.getConnection("jdbc:mysql:///ineuron", "root", "admin");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
	
		boolean flag=true;
		Scanner sc= new Scanner(System.in);
		while(flag)
	{
			System.out.println("-----Student details ----");
		System.out.println("press 1 to insert details");
		System.out.println("press 2 to update details");
		System.out.println("press 3 to delete details");
		System.out.println("press 4 to read details");
		System.out.println("enter any other number to exit");
		try
		{			switch(sc.nextInt())
			{
			case 1:
				PreparedStatement st1=con.prepareStatement("insert into student_assg values(?,?,?,?)");
				System.out.println("please enter the student id");
				st1.setInt(1, sc.nextInt());
				System.out.println("please enter the student name");
				st1.setString(2, sc.next());
				System.out.println("please enter the student age");
				st1.setInt(3, sc.nextInt());
				System.out.println("please enter the student enrolled course");
				st1.setString(4, sc.next());
				
				int i=st1.executeUpdate();
				System.out.println(i>0? "record inserted":"record not inserted");
				break;
			case 2:
				System.out.println("allowed to change name and age only");
				PreparedStatement st2= con.prepareStatement("update student_assg set name=?,age=? where id=?");
				System.out.println("please enter the student name");
				st2.setString(1, sc.next());
				System.out.println("please enter the student age");
				st2.setInt(2, sc.nextInt());
				System.out.println("enter the id");
				st2.setInt(3, sc.nextInt());
				int i2=st2.executeUpdate();
				System.out.println(i2>0? "record updated":"record not updated");
				break;
			case 3:
				System.out.println("enter the student id to delete");
				PreparedStatement st3= con.prepareStatement("delete from student_assg where id=?");
				st3.setInt(1,sc.nextInt());
				System.out.println(st3.executeUpdate()>0?"record deleted":"record  not  deleted");
				break;
			case 4:
				PreparedStatement st4 = con.prepareStatement("select * from student_assg");
				if (st4 != null) {
					ResultSet resultSet = st4.executeQuery();
					if (resultSet!= null) {
						System.out.println(" see the below for all student details I mean in console ");
						while (resultSet.next()) {
							System.out.print(resultSet.getInt(1) + " " + resultSet.getString("name")+" "
									+resultSet.getInt("age")+" "+resultSet.getString("course"));
							System.out.println();
						}
					}
					else
						System.out.println("no details found");

				}
				break;
			default:
				System.out.println("confirmation: enter 0 to exit");
				flag=sc.nextInt()==0?false:true;
				break;
			
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			break;
		}
	}
		
	}
}
