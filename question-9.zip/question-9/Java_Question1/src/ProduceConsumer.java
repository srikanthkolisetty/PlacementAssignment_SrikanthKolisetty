import java.util.ArrayList;
import java.util.List;

public class ProduceConsumer {
	
	public static void main(String[] args) {
		
		ArrayList arrayList = new ArrayList();
		Thread t1= new Thread(new Producer(arrayList,5),"producer");
		Thread t2= new Thread(new Consumer(arrayList,5),"consumer");
		t1.start();
		t2.start();
	}

}

class Producer implements Runnable
{
	public List li;
	public int size;
	Producer(List li,int size)
	{
		this.li=li;
		this.size=size;
	}
	@Override
	public void run() {
		
		for(int i=0;i<10;i++)
		{
			try {
				System.out.println("in");
				produce(i);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void produce(int i) throws InterruptedException
	{
		while(li.size()==size)
			synchronized(li)
			{
				System.out.println("producer waiting -queue full");
				li.wait();
			}
		
		synchronized(li)
		{
			li.add(i);
			li.notifyAll();			
		}
	}
}


class Consumer implements Runnable
{
	public List li;
	public int size;
	Consumer(List li,int size)
	{
		this.li=li;
		this.size=size;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			while(true)
			{				
				consume();
				Thread.sleep(2000);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void consume() throws InterruptedException
	{
		while(li.isEmpty())
			synchronized(li)
			{
				System.out.println("consumer waiting :queue empty");
				li.wait();
			}
		synchronized(li)
		{
			
			System.out.println("consumed:"+(Integer)li.remove(0));
			li.notifyAll();
		
		}
	}
}
