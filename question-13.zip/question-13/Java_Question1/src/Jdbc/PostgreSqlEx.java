package Jdbc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PostgreSqlEx {
	
	static Connection con;
	static PreparedStatement pst;
	static
	{
		try {
			con = DriverManager.getConnection("jdbc:postgresql:///ineuron", "postgres", "admin");
			if(con!=null)
			{
				pst= con.prepareStatement("insert into student values(?,?)");
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
public static void main(String[] args) throws IOException, SQLException {
	
	FileReader f= new FileReader(new File("E:\\batch.txt"));
	BufferedReader bu= new BufferedReader(f);
	String line;
	while((line=bu.readLine())!=null)
	{
		String[] sp=line.split(",");
		pst.setString(1,sp[0]);
		pst.setString(2,sp[1]);
		pst.addBatch();
	}
	pst.executeBatch();
}
}
