class Thread1 extends Thread
{
	public void run()
	{
		for(int i=1;i<=10;i++)
			if(i%2==0)
				System.out.println("even: "+i);
	}
}
class Thread2 extends Thread
{
	public void run()
	{
		for(int i=1;i<=10;i++)
			if(i%2!=0)
				System.out.println("odd: "+i);
	}
}


public class ThreadExample {

	public static void main(String[] args) {
		
		Thread1 th1= new Thread1();
		Thread2 th2= new Thread2();
		th1.start();
		th2.start();
	}
}
