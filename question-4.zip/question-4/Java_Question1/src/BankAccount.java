import java.util.Scanner;

public class BankAccount {

	public static void main(String[] args) {
		
		System.out.println("press 1 to deposit");
		System.out.println("press 2 to withdraw");
		System.out.println("press 3 to checkbalance");
		
		int balance=0;
		switch(new Scanner(System.in).nextInt())
		{
		case 1:
			System.out.println("please enter the amount to be deposited");
			balance+=new Scanner(System.in).nextInt();
			System.out.println("your balance is"+balance);
			break;
		case 2:
			System.out.println("please enter the amount to be withdraw");
			if(new Scanner(System.in).nextInt()<=balance)
				System.out.println("please collect your money");
			else
				System.out.println("Insufficient balance");
			break;
		case 3:
				System.out.println("your balance is"+balance);
				break;
		default:
				System.out.println("please choose correct option");
				break;
		}
		
	}
	
}
