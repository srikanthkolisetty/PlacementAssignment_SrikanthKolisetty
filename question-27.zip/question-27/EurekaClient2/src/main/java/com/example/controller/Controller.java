package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController("/map")
public class Controller {
	
	@Autowired
	private IFiegn fi;
	
	@GetMapping("/data/{id}")
	public ResponseEntity<Product> get(@PathVariable Integer id) throws Exception
	{
		System.out.println("ji");
		ResponseEntity<Product> product = fi.getProduct(id);
		
		return product;
	}

}
