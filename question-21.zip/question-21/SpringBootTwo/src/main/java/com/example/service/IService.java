package com.example.service;

import com.example.dto.Diary;

public interface IService {

	public void insert(Diary d);
}
