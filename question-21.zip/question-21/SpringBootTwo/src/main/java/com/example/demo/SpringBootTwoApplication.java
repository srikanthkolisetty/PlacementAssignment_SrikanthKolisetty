package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.example.dto.Diary;
import com.example.service.IServiceImpl;

@SpringBootApplication(scanBasePackages = "com.example")
@EntityScan(basePackages = {"com.example.dto"} )
@EnableJpaRepositories(basePackages = {"com.example.dao"})
public class SpringBootTwoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(SpringBootTwoApplication.class, args);
	
		IServiceImpl impl = run.getBean(IServiceImpl.class);
		Diary d = new Diary();
		d.setAreaName("india");
		d.setDairyName("cow");
		d.setNoOfAcres(33);
		impl.insert(d);
	
	}

}
