package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.example.dao.Repo;
import com.example.dto.Diary;

@Service
public class IServiceImpl implements IService{

	@Autowired
	private Repo obj;
	
	@Override
	public void insert(Diary d) {
		// TODO Auto-generated method stub
		try
		{
			obj.save(d);
			
		}
		catch(DataAccessException e)
		{
			e.printStackTrace();
		}
	}

}
