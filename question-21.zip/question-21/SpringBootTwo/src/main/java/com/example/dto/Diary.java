package com.example.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class Diary {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	public Integer id;
	
	public String dairyName;
	
	public String areaName;
	
	public Integer noOfAcres;
	
}
